import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class UnreliableChannel {
    private static final int SERVER_PORT = 9876;
    private static final int TIMEOUT = 10_000; // Server shutdown timeout after the last client interaction (in ms)
    private static long lastInteractionTime = System.currentTimeMillis(); // Tracks the last client interaction

    // Maps for storing client information and statistics
    private static final HashMap<String, ClientInfo> clientMap = new HashMap<>();
    private static final HashMap<String, Queue<DatagramPacket>> offlineQueueMap = new HashMap<>();
    private static final HashMap<String, Integer> packetsReceived = new HashMap<>();
    private static final HashMap<String, Integer> packetsLost = new HashMap<>();
    private static final HashMap<String, Integer> packetsDelayed = new HashMap<>();
    private static final HashMap<String, Long> totalDelay = new HashMap<>();

    public static void main(String[] args) throws Exception {
        // Parse command-line arguments: loss probability, min delay, and max delay
        double lossProbability = Double.parseDouble(args[0]); // e.g., 0.3
        int minDelay = Integer.parseInt(args[1]); // e.g., 0 ms
        int maxDelay = Integer.parseInt(args[2]); // e.g., 200 ms

        DatagramSocket serverSocket = new DatagramSocket(SERVER_PORT);
        System.out.println("Server running on port: " + SERVER_PORT);

        // Start a thread to process queued packets for offline receivers
        new Thread(() -> processOfflineQueues(serverSocket)).start();

        // Main server loop
        while (true) {
            synchronized (UnreliableChannel.class) {
                if (System.currentTimeMillis() - lastInteractionTime > TIMEOUT) {
                    System.out.println("Server timeout reached. Shutting down...");
                    break;
                }
            }

            byte[] receiveBuffer = new byte[1024];
            DatagramPacket receivePacket = new DatagramPacket(receiveBuffer, receiveBuffer.length);

            try {
                serverSocket.setSoTimeout(TIMEOUT);
                serverSocket.receive(receivePacket);

                synchronized (UnreliableChannel.class) {
                    lastInteractionTime = System.currentTimeMillis();
                }

                // Spawn a new thread to process the received packet
                new Thread(() -> handleClient(receivePacket, serverSocket, lossProbability, minDelay, maxDelay))
                        .start();
            } catch (SocketTimeoutException e) {
                // No packet received within the timeout, continue to check for server shutdown
            }
        }

        serverSocket.close();
        displayStatistics();
    }

    /**
     * Handles processing of a single client packet.
     * Registers clients and forwards packets to the intended receiver.
     */
    private static void handleClient(DatagramPacket receivePacket, DatagramSocket serverSocket,
            double lossProbability, int minDelay, int maxDelay) {
        try {
            String message = new String(receivePacket.getData(), 0, receivePacket.getLength());
            InetAddress senderAddress = receivePacket.getAddress();
            int senderPort = receivePacket.getPort();

            // Parse sender and receiver from the message
            String[] parts = message.split(" ");
            if (parts.length < 2) {
                return; // Invalid message
            }
            String sender = parts[0];
            String receiver = parts[1];
            String key = sender + " to " + receiver;

            // Register the sender in the client map
            synchronized (clientMap) {
                clientMap.put(sender, new ClientInfo(senderAddress, senderPort));
            }

            // Simulate packet loss
            Random random = new Random();
            if (random.nextDouble() <= lossProbability) {
                synchronized (packetsLost) {
                    packetsLost.put(key, packetsLost.getOrDefault(key, 0) + 1);
                }
                return;
            }

            // Simulate delay
            int delay = minDelay + random.nextInt(maxDelay - minDelay + 1);
            Thread.sleep(delay);

            // Update statistics
            synchronized (packetsReceived) {
                packetsReceived.put(key, packetsReceived.getOrDefault(key, 0) + 1);
            }
            synchronized (packetsDelayed) {
                packetsDelayed.put(key, packetsDelayed.getOrDefault(key, 0) + 1);
            }
            synchronized (totalDelay) {
                totalDelay.put(key, totalDelay.getOrDefault(key, 0L) + delay);
            }

            // Check if receiver is online
            ClientInfo receiverInfo;
            synchronized (clientMap) {
                receiverInfo = clientMap.get(receiver);
            }

            if (receiverInfo != null) {
                // Forward the packet to the intended receiver
                DatagramPacket forwardPacket = new DatagramPacket(
                        receivePacket.getData(),
                        receivePacket.getLength(),
                        receiverInfo.getAddress(),
                        receiverInfo.getPort());
                serverSocket.send(forwardPacket);
            } else {
                // Add the packet to the offline queue
                synchronized (offlineQueueMap) {
                    offlineQueueMap.computeIfAbsent(receiver, k -> new LinkedList<>()).add(receivePacket);
                }
                System.out.println("Receiver " + receiver + " is offline. Packet queued.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Idea from chatgpt
    /**
     * Processes queued packets for offline receivers.
     * Periodically checks if receivers are online and sends queued packets to them.
     */
    private static void processOfflineQueues(DatagramSocket serverSocket) {
        while (true) {
            synchronized (offlineQueueMap) {
                Iterator<Map.Entry<String, Queue<DatagramPacket>>> iterator = offlineQueueMap.entrySet().iterator();
                while (iterator.hasNext()) {
                    Map.Entry<String, Queue<DatagramPacket>> entry = iterator.next();
                    String receiver = entry.getKey();
                    Queue<DatagramPacket> queue = entry.getValue();

                    ClientInfo receiverInfo;
                    synchronized (clientMap) {
                        receiverInfo = clientMap.get(receiver);
                    }

                    if (receiverInfo != null) { // Receiver is now online
                        System.out.println("Receiver " + receiver + " is online. Sending queued packets.");
                        while (!queue.isEmpty()) {
                            DatagramPacket packet = queue.poll(); // Remove packet from the queue
                            try {
                                DatagramPacket forwardPacket = new DatagramPacket(
                                        packet.getData(),
                                        packet.getLength(),
                                        receiverInfo.getAddress(),
                                        receiverInfo.getPort());
                                serverSocket.send(forwardPacket); // Send the packet
                                System.out.println("Packet sent to receiver " + receiver);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        iterator.remove(); // Remove the queue after all packets are sent
                    }
                }
            }

            try {
                Thread.sleep(1000); // Check queues every second
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }

    /**
     * Displays statistics for all packets handled by the server.
     */
    private static void displayStatistics() {
        System.out.println("\nFinal Statistics:");
        synchronized (packetsReceived) {
            for (String key : packetsReceived.keySet()) {
                int received = packetsReceived.getOrDefault(key, 0);
                int lost = packetsLost.getOrDefault(key, 0);
                int delayed = packetsDelayed.getOrDefault(key, 0);
                long totalDelayForKey = totalDelay.getOrDefault(key, 0L);
                double averageDelay = received > 0 ? (double) totalDelayForKey / received : 0;

                System.out.println(
                        "Packets " + key + ": Received: " + received + " | Lost: " + lost + " | Delayed: " + delayed);
                System.out.printf("Average delay %s: %.2f ms%n", key, averageDelay);
            }
        }
    }

    /**
     * A helper class to store client information (address and port).
     */
    private static class ClientInfo {
        private final InetAddress address;
        private final int port;

        public ClientInfo(InetAddress address, int port) {
            this.address = address;
            this.port = port;
        }

        public InetAddress getAddress() {
            return address;
        }

        public int getPort() {
            return port;
        }
    }
}
