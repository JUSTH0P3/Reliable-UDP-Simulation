import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class Clients {

    public static int receivedPackets = 0; // Counter to track the number of received packets

    public static void main(String[] args) throws Exception {
        // Parse command-line arguments for sender and receiver identifiers
        String sender = args[0]; // e.g., "A" or "B"
        String receiver = args[1]; // e.g., "B" or "A"
        int serverPort = 9876; // The server's port, hardcoded for simplicity

        // Create a DatagramSocket for sending and receiving packets
        DatagramSocket clientSocket = new DatagramSocket();
        InetAddress serverAddress = InetAddress.getByName("localhost");

        // Start a separate thread to handle receiving packets
        Thread receiveThread = new Thread(() -> {
            byte[] buffer = new byte[1024]; // Buffer for receiving data
            String received = "";
            while (!received.equals("END")) { // Loop until the "END" signal is received
                DatagramPacket receivePacket = new DatagramPacket(buffer, buffer.length);
                try {
                    clientSocket.receive(receivePacket); // Receive packet from the server
                    received = new String(receivePacket.getData(), 0, receivePacket.getLength());
                    System.out.println("I am " + sender + " and I received: " + received);
                    receivedPackets++;
                } catch (IOException e) {
                    break; // Exit the loop if an error occurs
                }
            }
        });
        receiveThread.start();

        // Send packets to the server
        for (int i = 0; i < 1000; i++) { // Sending 1000 packets
            String message = sender + " " + receiver + " " + (i % 2);
            byte[] sendData = message.getBytes();
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, serverAddress, serverPort);
            clientSocket.send(sendPacket);
            Thread.sleep(500); // Wait for 0.5 seconds between packets as instructed
        }

        // Wait for 5 seconds to allow the offline queue to be processed
        System.out.println("Waiting to allow server to empty offline queue...");
        Thread.sleep(5000);

        // Send an "END" signal to indicate the client is done
        String endSignal = "END";
        byte[] endData = endSignal.getBytes();
        DatagramPacket endPacket = new DatagramPacket(endData, endData.length, serverAddress, serverPort);
        clientSocket.send(endPacket);

        // Close the client socket and wait for the receiving thread to finish
        clientSocket.close();
        try {
            receiveThread.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        // Print the total number of received packets
        System.out.println("Received packets: " + receivedPackets);
    }
}
