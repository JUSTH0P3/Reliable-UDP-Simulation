// Updated RUDPSource.java to send the file name

import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.*;

public class RUDPSource {
    public static void main(String[] args) {
        if (args.length < 3 || !args[0].equals("-r") || !args[2].equals("-f")) {
            System.out.println("Usage: java RUDPSource -r <recvHost>:<recvPort> -f <fileName>");
            return;
        }

        String[] hostPort = args[1].split(":");
        String host = hostPort[0];
        int port = Integer.parseInt(hostPort[1]);
        String fileName = args[3];

        double lossProbability = 0.2;
        Random random = new Random();

        try {
            InetAddress receiverAddress = InetAddress.getByName(host);
            DatagramSocket socket = new DatagramSocket();
            socket.setSoTimeout(400); // Static timeout for simplicity

            // Send file name as the first packet
            byte[] fileNameBytes = fileName.getBytes();
            DatagramPacket fileNamePacket = new DatagramPacket(fileNameBytes, fileNameBytes.length, receiverAddress,
                    port);
            socket.send(fileNamePacket);

            File file = new File(fileName);
            if (!file.exists()) {
                System.out.println("File not found: " + fileName);
                return;
            }
            // Measure transmission start time
            long startTime = System.nanoTime(); // Start timer

            FileInputStream fis = new FileInputStream(file);
            byte[] buffer = new byte[1020];
            Map<Integer, byte[]> packets = new HashMap<>();
            int seqNum = 0;

            while (true) {
                int bytesRead = fis.read(buffer);
                if (bytesRead == -1)
                    break;

                ByteBuffer packetBuffer = ByteBuffer.allocate(1024);
                packetBuffer.putInt(seqNum);
                packetBuffer.put(buffer, 0, bytesRead);

                packets.put(seqNum, packetBuffer.array());
                seqNum++;
            }

            fis.close();

            boolean transferComplete = false;
            int expectedAckSeq = 0; // Track the next expected acknowledgment

            while (!transferComplete) {
                transferComplete = true;
                for (int i = expectedAckSeq; i < packets.size(); i++) {
                    byte[] packetData = packets.get(i);

                    System.out.printf("[DATA TRANSMISSION]: %d | %d\n", i, packetData.length);

                    // Simulate packet loss
                    if (random.nextDouble() <= lossProbability) {
                        System.out.println("Simulating packet loss for packet " + i);
                        transferComplete = false;
                        break;
                    }

                    // Send the packet
                    DatagramPacket packet = new DatagramPacket(packetData, packetData.length, receiverAddress, port);
                    socket.send(packet);

                    try {
                        while (true) {
                            byte[] ackBuffer = new byte[1024];
                            DatagramPacket ackPacket = new DatagramPacket(ackBuffer, ackBuffer.length);
                            socket.receive(ackPacket);

                            ByteBuffer ackBufferWrap = ByteBuffer.wrap(ackPacket.getData());
                            int ackSeqNum = ackBufferWrap.getInt();
                            System.out.printf("[ACK RECEIVED]: %d\n", ackSeqNum);

                            if (ackSeqNum == i) {
                                expectedAckSeq++; // Move to the next packet
                                break;
                            } else {
                                System.out.printf("[INVALID ACK]: Received %d, expected %d\n", ackSeqNum, i);
                                // Ignore invalid ACK and keep waiting
                            }
                        }
                    } catch (SocketTimeoutException e) {
                        System.out.printf("[TIMEOUT]: Resending packet %d\n", i);
                        transferComplete = false; // Retransmit this packet
                        break;
                    }
                }
            }

            // Send END packet
            byte[] endPacket = ByteBuffer.allocate(4).putInt(-1).array();
            DatagramPacket end = new DatagramPacket(endPacket, endPacket.length, receiverAddress, port);
            socket.send(end);

            // Measure transmission end time and calculate total time
            long endTime = System.nanoTime(); // End timer
            double totalTimeSeconds = (endTime - startTime) / 1_000_000_000.0; // Convert to seconds

            socket.close();
            System.out.println("[COMPLETE]");

            System.out.printf("Total transmission time: %.2f seconds\n", totalTimeSeconds); // Display result

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
