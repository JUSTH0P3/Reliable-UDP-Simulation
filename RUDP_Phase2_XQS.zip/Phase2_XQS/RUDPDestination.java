// Updated RUDPDestination.java with source-to-destination delay simulation

import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.*;

public class RUDPDestination {
    public static void main(String[] args) {
        if (args.length != 2 || !args[0].equals("-p")) {
            System.out.println("Usage: java RUDPDestination -p <recvPort>");
            return;
        }

        int port = Integer.parseInt(args[1]);
        Random random = new Random(); // Random generator for simulating delays

        try {
            DatagramSocket socket = new DatagramSocket(port);
            byte[] buffer = new byte[1024]; // Buffer to hold incoming packets
            TreeMap<Integer, byte[]> receivedPackets = new TreeMap<>(); // TreeMap to order packets by sequence number
            Map<Integer, Boolean> receivedStatus = new HashMap<>(); // Map to track received packets

            // Receive the file name
            DatagramPacket fileNamePacket = new DatagramPacket(buffer, buffer.length);
            socket.receive(fileNamePacket);

            // Convert the received data to a string and trim it
            String originalFileName = new String(fileNamePacket.getData(), 0, fileNamePacket.getLength()).trim();

            // Remove the .txt extension if it exists
            String baseFileName = originalFileName.endsWith(".txt")
                    ? originalFileName.substring(0, originalFileName.length() - 4)
                    : originalFileName;

            // Add -copy.txt to the base file name
            String fileName = baseFileName + "-copy.txt";

            boolean transferComplete = false;

            while (!transferComplete) {
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                socket.receive(packet);

                // Simulate source-to-destination network delay
                int networkDelay = random.nextInt(300); // Random delay between 0 and 300 ms
                long processTime = System.currentTimeMillis() + networkDelay;
                while (System.currentTimeMillis() < processTime) {
                    // Busy-wait to simulate network delay
                }

                ByteBuffer packetBuffer = ByteBuffer.wrap(packet.getData());
                int seqNum = packetBuffer.getInt(); // Extract sequence number

                if (seqNum == -1) {
                    // End of transfer
                    transferComplete = true;
                    System.out.println("[COMPLETE]");
                    break;
                }
                System.out.printf("[PACKET RECEIVED]: Simulated delay %d ms\n", networkDelay);

                byte[] packetData = Arrays.copyOfRange(packet.getData(), 4, packet.getLength());

                if (receivedStatus.getOrDefault(seqNum, false)) {
                    // If packet is a duplicate
                    System.out.printf("[DATA RECEPTION]: %d | %d | DISCARDED\n", seqNum, packetData.length);
                } else {
                    // If packet is new
                    receivedPackets.put(seqNum, packetData);
                    receivedStatus.put(seqNum, true);
                    System.out.printf("[DATA RECEPTION]: %d | %d | OK\n", seqNum, packetData.length);
                }

                // Simulate acknowledgment delay
                int ackDelay = random.nextInt(300); // Random delay between 0 and 300 ms
                long ackSendTime = System.currentTimeMillis() + ackDelay;
                while (System.currentTimeMillis() < ackSendTime) {
                    // Busy-wait to simulate acknowledgment delay
                }

                // Send ACK
                ByteBuffer ackBuffer = ByteBuffer.allocate(4);
                ackBuffer.putInt(seqNum);
                DatagramPacket ackPacket = new DatagramPacket(ackBuffer.array(), ackBuffer.capacity(),
                        packet.getAddress(), packet.getPort());
                socket.send(ackPacket);
                System.out.printf("[ACK SENT]: %d after %d ms delay\n", seqNum, ackDelay);

            }

            // Write packets in order to file
            FileOutputStream fos = new FileOutputStream(fileName);
            for (byte[] packetData : receivedPackets.values()) {
                fos.write(packetData);
            }

            fos.close();
            socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
